import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xFF4CAF50);
  static const background = Colors.white;
  static const textDark = Colors.black87;
  static const navBg = Colors.white;
}
